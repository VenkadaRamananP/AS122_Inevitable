from django.urls import path
from . import views
from sih.models import details
urlpatterns =[path("",views.index,name="index"),path("get1",views.sendotp,name="get"),path("input",views.register,name='reg'),path("otp",views.get,name='h'),
path("resend",views.resend,name="reotp"),path("login",views.login,name="login"),path("main",views.index,name="ind")]

