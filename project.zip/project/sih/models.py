from django.db import models

# Create your models here.
class details(models.Model):
    name=models.CharField(max_length=40)
    dob=models.CharField(max_length=25)
    kyc=models.CharField(max_length=15)
    address=models.TextField()
    dist=models.CharField(max_length=40)
    pin=models.CharField(max_length=6)
    state=models.CharField(max_length=36)
    number=models.CharField(max_length=10)

class One_time_password(models.Model):
    phno=models.CharField(max_length=10)
    otp=models.CharField(max_length=6)
    date=models.DateField()




