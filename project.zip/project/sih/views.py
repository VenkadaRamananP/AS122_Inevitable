from django.shortcuts import render,redirect
import pyttsx3,psycopg2
from .models import details,One_time_password
from django.contrib import messages
from django.http import HttpResponse
# Create your views here.



def sendotp(request):
    val1 = request.POST['number']
    file1 = open("MyFile.txt","w") 
    file1.write(val1) 
    file1.close()

    import psycopg2
    import random
    global OTP
    OTP= random.randint(0000,9999)
    print(OTP)
    conn = psycopg2.connect(database = "sriram", user = "postgres", password = "1234", host = "localhost")
    cur = conn.cursor()
    cur.execute("SELECT number FROM sih_details")
    rows = cur.fetchall()
    conn.close()
    length=len(rows) 
    for i in range(length):
        if val1==rows[i][0]:
            # GENERATE OTP
            f=OTP
            gen="THE OTP IS {}"
            send=gen.format(f) 
            #SEND OTP
            import requests

            url = "https://www.fast2sms.com/dev/bulk"

            querystring = {"authorization":"nhM08LTaLy7Pm9W8vOBpOOMdXN6LvnruRFMVodOz1oM16jqFT5eeo5F3ga42","sender_id":"FSTSMS","message":send,"language":"english","route":"p","numbers":val1}

            headers = {
                'cache-control': "no-cache"
            }

            response = requests.request("GET", url, headers=headers, params=querystring)

            print(response.text)
            return render(request,"otp_page.html")
        else:
            pass
    else:
        return render(request,"extend.html")
    

def index(request):
    return render(request,"index1.html")
def login(request):
    return render(request,"index.html")


def resend(request):
            file1 = open("myfile.txt","r") 
            number=file1.read() 
            file1.close() 
            f=OTP
            gen="THE OTP IS {}"
            send=gen.format(f)
            import requests

            url = "https://www.fast2sms.com/dev/bulk"

            querystring = {"authorization":"nhM08LTaLy7Pm9W8vOBpOOMdXN6LvnruRFMVodOz1oM16jqFT5eeo5F3ga42","sender_id":"FSTSMS","message":send,"language":"english","route":"p","numbers":number}

            headers = {
                'cache-control': "no-cache"
            }

            response = requests.request("GET", url, headers=headers, params=querystring)

            print(response.text)
            return render(request,"otp_page.html")



    


            

    
    

        
def get(request):
        file1 = open("myfile.txt","r") 
        number=file1.read() 
        file1.close()
    
    
        import datetime
        now = datetime.datetime.now()
        date= now.strftime("%Y-%m-%d")
        
        val2 =int(request.POST['otp'])
        pin=OTP
        
        user1= One_time_password (phno=number,otp=pin,date=date)
        user1.save()
        if (OTP == val2):
            file1 = open("myfile.txt","r") 
            number=file1.read() 
            file1.close() 

            conn = psycopg2.connect(database = "sriram", user = "postgres", password = "1234", host = "localhost")
            cur = conn.cursor()
            cur.execute("SELECT number,name FROM sih_details")
            rows = cur.fetchall()
            conn.close()
            length=len(rows) 
            for i in range(length):
                if number==rows[i][0]:
                    name=rows[i][1]
    
            return render(request,"req.html",{'name':name})
        else:
        
            messages.info(request,"WRONG OTP")
            return render(request,"otp_page.html")    
    
    
    
def register(request):
    if request.method =='POST':
        nam=request.POST['name']
        dob=request.POST['birthday']
        kyc=request.POST['kyc']
        add=request.POST['address']
        dis=request.POST['district']
        state=request.POST['state']
        pin_code=request.POST['pincode']
        m_number=request.POST['m_number']
        user = details(number=m_number,name=nam,dob=dob,kyc=kyc,address=add,dist=dis,state=state,pin=pin_code)
        user.save()
        return render(request,"index.html")
       
    else:
        return render(request,"extend.html")

    
    
    
    
    
   


