from django.apps import AppConfig


class SihConfig(AppConfig):
    name = 'sih'
